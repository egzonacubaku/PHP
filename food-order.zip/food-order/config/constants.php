<?php 
//Start Session;
session_start();

//3. Execute Quary and Save Data in DB
//create constants to store non repeating values
//constants shkruhen me shkrojna te medha ndersa variablat me te vogla
define('SITEURL','http://localhost/food-order/');
define('LOCALHOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','food-order');

$conn =mysqli_connect(LOCALHOST,DB_USERNAME, DB_PASSWORD) or die(mysqli_error('')) ; //DB Connection
$db_select= mysqli_select_db($conn,DB_NAME) or die(mysqli_error('')); //Selecting Database

?>