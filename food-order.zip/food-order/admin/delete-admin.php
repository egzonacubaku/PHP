<?php

    //include constants.php file here
    include('../config/constants.php');

    //1. get the id of admin to be deleted 
      $id=$_GET['id'];
    //2. create qal query to delete aadmin
        $sql = "DELETE FROM tbl_admin WHERE id=$id";

    //execute the query
    $res = mysqli_query($conn,$sql);
    //check weather the query executed sucsesfully or not
    if($res==true){
        //query executed succesfully and admin deleted
        //echo "Admin deleted";
        //create session variable to display mesages 
        $_SESSION['delete']= "<div class='success'>Admin Deleted Successfully</div>";
        //Redirect to Manage Admin Page
        header('location:'.SITEURL.'admin/manage-admin.php');
    }
    else{
        //failed to delete admin 
        //echo "Failed to delete admin";
        $_SESSION['delete']= "<div class='error' > Failed to delete Admin.Try again</div";
        header('location:'.SITEURL.'admin/manage-admin.php');
    }
    //3.Redirect to manage admin page with mesages (succses/error)

?>