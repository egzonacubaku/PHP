<!-- Footer Section Starts-->
<div class="footer">
            <div class="wrapper"> 
                <p class="text-center">2021 All rights reserved . Developed By :- <a href="a"> Egzona Cubaku</a> </p>
            </div>  
         </div>
         <!-- Footer Section Ends-->


    </body>
</html>