<!-- Fillimi i Header per user te kycur -->
<header class="ht-header">
	<div class="container">
		<nav class="navbar navbar-default navbar-custom">
				<div class="navbar-header logo">
				    <div class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					    <span class="sr-only">Toggle navigation</span>
					    <div id="nav-icon1">
							<span></span>
							<span></span>
							<span></span>
						</div>
				    </div>
				    <a href="welcome.php"><img class="logo" src="images/logo.png" alt=""></a>
			    </div>
				<div class="collapse navbar-collapse flex-parent" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav flex-child-menu menu-left">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li><a href="welcome.php">Home</a></li>
						<li><a href="moviegrid.php">Filma</a></li>
					</ul>	
					<ul class="nav navbar-nav flex-child-menu menu-right">               
						<li><a href="profili_im.php">Profili im</a></li>
						<li class="btn"><a href="logout.php">Dil</a></li>
					</ul>
				</div>
	    </nav>

