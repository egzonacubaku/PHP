<!-- Fillimi i Header per nje user "guest" -->
<header class="ht-header">
	<div class="container">
		<nav class="navbar navbar-default navbar-custom">
				<div class="navbar-header logo">
				    <div class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					    <span class="sr-only">Toggle navigation</span>
					    <div id="nav-icon1">
							<span></span>
							<span></span>
							<span></span>
						</div>
				    </div>
				    <a href="index.php"><img class="logo" src="images/logo.png"></a>
			    </div>
				<div class="collapse navbar-collapse flex-parent" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav flex-child-menu menu-left">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li><a href="index.php">Home</a></li>
						<li><a href="login.php">Filma</a></li>
						<li><a href="/movie/admin/login.php">Admin Panel</a></li>
					</ul>	
					<ul class="nav navbar-nav flex-child-menu menu-right">               
						<li><a href="login.php">Kyçu</a></li>
						<li class="btn"><a href="signup.php">Regjistrohu</a></li>
					</ul>
				</div>
	    </nav>

