<?php include('partials/menu.php') ; ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Shto Zhaner </h1>
        <br><br>

        <?php 
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add'];
                unset($_SESSION['add']);
            }

            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }


            
        ?>
        <br><br>
        <!--Forma per te shtuar zhanret  -->
            <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-30">
                    <tr>
                        <td>Titulli: </td>
                        <td>
                            <input type="text" name="title" placeholder="Shkruaj titullin" >
                        </td>
                    </tr>

                    <tr>
                        <td>Përshkrimi: </td>
                        <td>
                            
                            <textarea name="description" placeholder="..." cols="25" rows="5" ></textarea>
                        </td>
                    </tr>

                   

                   

                    <tr>
                        <td colspan="2">
                            <input type="submit" name="submit" value="Shto" class="btn-secondary" >
                        </td>
                    </tr>

                </table>
                </form>
                </div>

</div>
         <!--mbaron forma-->
        
        <?php 
           
            if(isset($_POST['submit']))
            {
               

                //1.merr te dhena nga forma 
                $title = $_POST['title'];
                $description = $_POST['description'];

               

                //2. insert data ne db 
                if(!preg_match('~[0-9]+~', $title) && preg_match( '/[a-zA-Z]/ ', $title) && !preg_match('~/[^a-zA-Z\d]/+~', $title) && !empty($title)) 
                {

                    $sql_u = "SELECT * FROM genre WHERE title='$title'";
                    $res_u = mysqli_query($conn, $sql_u);
                    if (mysqli_num_rows($res_u) > 0) 
                    {
                        $_SESSION['add'] = "<div class='error'>Ky zhaner egziston.</div>";
                        //kthim tek manage genre 
                        header('location:'.SITEURL. 'admin/add-genre.php');
                    }
                    else {

                        $sql = "INSERT INTO genre SET
                            title ='$title',
                            description = '$description'
                            ";
                        

                        //3.execute query 
                        $res = mysqli_query($conn, $sql); // menu ka contants 

                        //4. kontroll nese query eshte egzekutuar 
                        if($res==true)
                        {
                            
                            $_SESSION['add'] = "<div class='success'>Zhanri u shtua me sukses.</div>";
                            //kthim tek manage genre 
                            header('location:'.SITEURL. 'admin/manage-genre.php');
                        }
                        else
                        {
                            //zhanri nuk eshte shtuar, do shfaqet mesazhi
                            $_SESSION['add'] = "<div class='error'>Zhanri nuk u shtua ! Provo perseri.</div>";
                            
                            header('location:'.SITEURL. 'admin/add-genre.php');
                        }
                    
                   
                    }
                }
                
                    else
                    {
                        $_SESSION['add'] = "<div class='error'>Zhanri nuk u shtua ! Titulli duhet te jete tekst.</div>";
                            
                        header('location:'.SITEURL. 'admin/add-genre.php');
                    }
                }
            
        ?>


   
<?php include('partials/footer.php') ; ?>