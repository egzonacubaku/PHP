<?php include('partials/menu.php') ?>

     
         <div class="main-content">
            <div class="wrapper"> 
                <h1>MovieTime.</h1>
                <h1>Menaxhoni filmat tuaj!</h1>
                <br><br>
                 <?php 
                //kete kopjoje dhe tek index.php
                    if(isset($_SESSION['login']))
                    {
                        echo $_SESSION['login'];
                        unset($_SESSION['login']);
                    }
                ?>
                <br><br>
                <div class="text-center">
                <img src="https://images.unsplash.com/photo-1535016120720-40c646be5580?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80">
              
                    <br/>
                    
                </div>

               
                <div class="clearfix"></div>
            </div>   
         </div>
       
        
<?php  include('partials/footer.php') ?>