<?php include('partials/menu.php') ?>

      
         <div class="main-content">
            <div class="wrapper"> 
                <h1> Administrator</h1>
                <br /><br />
                <?php 
                if(isset($_SESSION['add'])){
                    echo $_SESSION['add']; //Display session Message
                    unset($_SESSION['add']); //Kjo e heq mesazhin kur i behet refresh
                }
                if(isset($_SESSION['delete']))
                {
                    echo $_SESSION['delete'];
                    unset($_SESSION['delete']);
                }
                if(isset($_SESSION['update']))
                {
                    echo $_SESSION['update'];
                    unset($_SESSION['update']);
                }
                if(isset($_SESSION['user-not-found']))
                {
                    echo $_SESSION['user-not-found'];
                    unset($_SESSION['user-not-found']);
                }
                if(isset($_SESSION['pwd-not-match']))
                {
                    echo $_SESSION['pwd-not-match'];
                    unset($_SESSION['pwd-not-match']);
                }
                if(isset($_SESSION['change-pwd']))
                {
                    echo $_SESSION['change-pwd'];
                    unset($_SESSION['change-pwd']);
                   
                }


                ?>

                <!-- Butoni Add admin-->
                <br/><br/>
                <a href="add-admin.php" class="btn-primary">Shto Administratore </a>
                <br/> <br/> <br/>
               <table class="tbl-full">
                   <tr>
                       <th style="text-align:center;">Nr:</th>
                       <th style="text-align:center;">Emri</th>
                       <th style="text-align:center;">Username</th>
                       <th style="text-align:center;">Veprimet</th>
                   </tr>

                   <?php 
                   //Query per te marre te dhenat nga db per tabelen admin
                    $sql="SELECT * FROM admin";
                   
                    $res = mysqli_query($conn, $sql);

                    //kontroll nese query eshte egzekutuar apo jo
                    if($res==TRUE){
                        
                        $count=mysqli_num_rows($res); //function to get all the rules and db
                        $sn=1; //vendosim ne variabel sn i cili do rritet per cdo admin te shfaqur 
                        
                        if($count>0)
                        {
                                //ka te dhena ne db 
                                while($rows=mysqli_fetch_assoc($res)){
                                    //merr te dhenat nga db  
                                    
                                    $id=$rows['id'];
                                    $full_name=$rows['full_name'];
                                    $username=$rows['username'];

                                    //shaq te dhenat nga db ne tabele 
                                    ?>
                                      <tr>
                                    <td style="text-align:center;"><?php echo $sn++;?></td>
                                    <td style="text-align:center;"><?php echo $full_name;?></td>
                                    <td style="text-align:center;"><?php echo $username;?></td>
                                    <td style="text-align:center;">
                                            <a href="<?php echo SITEURL ;?>admin/update-password.php?id=<?php echo $id;?>" class="btn-extra">Ndrysho Kodin </a>
                                            <a href="<?php echo SITEURL ;?>admin/update-admin.php?id=<?php echo $id;?>" class="btn-secondary">Ndrysho të dhënat</a>
                                            <a href="<?php echo  SITEURL ;?>admin/delete-admin.php?id=<?php echo $id;?>" class="btn-danger">Fshij Admin </a>
                                    </td>
                                </tr>
                                
                                    <?php
                                }
                        }
                        else 
                        {
                            //nuk ka te dhena 
                        }

                    }

                   ?>
                  
               </table>
                
            </div>   
         </div>
        
        
    <?php include('partials/footer.php') ?>