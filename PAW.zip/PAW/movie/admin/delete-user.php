<?php

    //perfshihet file qe kemi lidhjen me db 
    include('../config/constants.php');

    //1. merr id e userit qe duam te fshijme 
      $id=$_GET['user_id'];
    //2. krijojme kodin sql per te fshire adminin
        $sql = "DELETE FROM user WHERE user_id=$id";

    
    $res = mysqli_query($conn,$sql);
    //kontroll nese query eshte egzekutuar apo jo
    if($res==true){
        //Admini u fshi , shfaq mesazhin  
        $_SESSION['delete']= "<div class='success'>Perdoruesi u fshi me sukses</div>";
      
        header('location:'.SITEURL.'admin/manage-users.php');
    }
    else{
       
        $_SESSION['delete']= "<div class='error' > Perdoruesi nuk u fshi. Provo përsëri..</div";
        header('location:'.SITEURL.'admin/manage-users.php');
    }
   

?>