<?php include('partials/menu.php') ; ?>
<div class="main-conten">
    <div class="wrapper">
        <h1> Shto perdorues</h1>
        <br><br>
        <?php 
            if(isset($_SESSION['add'])) // Kontroll nese session ka filluar apo jo
            {
                echo $_SESSION['add']; // shfaq mesazhin nese ka filluar sessioni
                unset($_SESSION['add']);//hiqet mesazhi
            }
        ?>

        <form action="" method="POST">
            <table class="tbl-30">
                
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" placeholder="Username"></td>
                </tr>
                <tr>
                    <td>Kodi</td>
                    <td><input type="password" name="password" placeholder="Shkruaj kodin "></td>
                </tr>
                
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Shto" class="btn-secondary">
                    </td>

                </tr>
            </table>
        </form>
    </div>
</div>



<?php include('partials/footer.php') ; ?>
<?php 
//Merr te dhena nga forma dhe ruaj ne db
//Kontroll nese butoni submit eshte klikuar apo jo
if(isset($_POST['submit']))
{
    //Button clicked 
   //1. Merr te dhenat nga forma
   
   $username=$_POST['username'];
   $password=md5($_POST['password']); //md5 e enkripton passwordin qe te mos lexohet

   //2.SQL Quary per te ruajtur te dhenat ne DB
    $sql="INSERT INTO user SET 
    
    username='$username',
    password='$password'
    
    ";
  //3. egzekutohet query
  $res = mysqli_query($conn, $sql) or die(mysqli_error($conn));
//4. kontroll nese query eshte egzekutuar apo jo
if($res==TRUE)
{
    //Data Inserted
  
   //krijo nje session per te shfaqur mesazhin
   $_SESSION['add']="<div class='success'>Perdoruesi u shtua me sukses.</div>";
  
   header("location:".SITEURL.'admin/manage-users.php');
}
else{
    //te dhenat nuk jane futur 
 
    //nje session per shfaqur mesazhin
   $_SESSION['add']="<div class='success'>Perdoruesi nuk u shtua.</div>";
 
   header("location:".SITEURL.'admin/add-user.php');
}
}

?>