<?php include('partials/menu.php');?>
<div class="main-content">
    <div class="wrapper">
        <h1>Ndrysho Kodin</h1>
        <br><br>
        
        <?php 
            if(isset($_GET['id']))
            {
                $id=$_GET['id'];
            }
        ?>
       <form action="" method="POST">

           <table class="tbl-30">
               <tr>
                    <td>Kodi aktual:  </td>
                    <td> <input type="password" name="current_password" placeholder="Kodi aktual">  </td>
                </tr>
                <tr>
                    <td>Kodi i ri:  </td>
                    <td> <input type="password" name="new_password" placeholder="Kodi i ri ">  </td>
                </tr>
                <tr>
                    <td>Konfirmo kodin:  </td>
                    <td> <input type="password" name="confirm_password" placeholder="Konfirmo">  </td>
                </tr>

                <tr>
                    <input type="hidden" name="id" value="<?php echo $id; ?>" >
                    <td colspan="2"> <input type="submit" name="submit" value="Ndrysho " class="btn-secondary"></td>
                    
                </tr>

           </table>
       </form>



    </div>
</div>
<?php 
        //kontroll nese butoni submit esht eklikuar 
        if(isset($_POST['submit']))
        {
           
           //merr te dhena nga forma 
           $id=$_POST['id'];
           $current_password = $_POST['current_password'];
           $new_password=$_POST['new_password'];
           $confirm_password=$_POST['confirm_password'];
  

           //kontroll nese admin/user me ate id dhe usename egziston 
           $sql = "SELECT * FROM admin WHERE id=$id AND password='$current_password'" ;
           
           //execute the query
           $res = mysqli_query($conn, $sql);
           if($res==true)
           {
                //kontroll nese ka te dhena 
                $count=mysqli_num_rows($res);

                if($count==1)
                {
                    //perdoruesi egzoston 
                            
                        $uppercase = preg_match('@[A-Z]@', $new_password); //kontrollet per fjalekalimin
                        $lowercase = preg_match('@[a-z]@', $new_password);
                        $numer = preg_match('@[0-9]@', $new_password);
                        $karakterspecial = preg_match('@[?=.*?[#?!$%^&*-]@', $new_password);
                        if (!$uppercase || !$lowercase || !$numer || !$karakterspecial || strlen($new_password) < 8)
                        {
                            
                            $_SESSION['add']="<div class='error'>Fjalëkalimi nuk është i saktë. Ai duhet të përmbajë jo më pak se 8 karaktere nga të cilat minimumi 1 gërmë të madhe, 1 numër dhe 1 karakter special.</div>";
                            //kthehu tek faqja manage admin
                            header("location:".SITEURL.'admin/manage-admin.php');
                            }
                    //kontroll nese  new pass dhe confirm password korespondojne 
                  else  if($new_password==$confirm_password)
                    {
                            //update password
                            
                            $sql2 = "UPDATE admin SET
                                password='$new_password'
                                WHERE id=$id
                            ";
                            //execute the query
                            $res2= mysqli_query($conn,$sql2);

                            //kontrollo nese query eshte egzekutuar 
                            if($res2==true)
                            {
                                //passwordi esht endryshuar , shfaq mesazhin 
                        $_SESSION['change-pwd']="<div class='success'>Kodi u ndryshua me sukses. </div>";
                        //redirect the user 
                        header('location:'.SITEURL.'admin/manage-admin.php');

                            }
                            else
                            {
                                //shfaq mesazh  errori
                                $_SESSION['change-pwd']="<div class='error'>Kodi nuk u ndryshua. </div>";
                        //redirect the user 
                        header('location:'.SITEURL.'admin/manage-admin.php');
                            }
                    }
                    else 
                    {
                        //passwordet nuk korrespondojne  , mesazh , kthim tek faqja manage-admin
                        $_SESSION['pwd-not-match']="<div class='error'>Nuk korespondojnë kodet me njëri-tjetrin. </div>";
                         
                        header('location:'.SITEURL.'admin/manage-admin.php');
                    }
                }
                else
                {
                    //nuk korespondon id dhe username , perdoruesi nuk egziston
                    $_SESSION['user-not-found']="<div class='error'>Përdoruesi nuk u gjet. </div>";
                    //redirect the user 
                    header('location:'.SITEURL.'admin/manage-admin.php');
                }
           }

            
        }

?>

<?php include('partials/footer.php');?>