<?php

   
    include('../config/constants.php');

    //1. merr id e zhanrit qe o fshijme  
      $gnr_id=$_GET['gnr_id'];
    //2. ckrijo kodin sql per ta fshire 
        $sql = "DELETE FROM genre WHERE gnr_id=$gnr_id";

    //execute the query
    $res = mysqli_query($conn,$sql);
    //kontroll nese fshirja eshte bere apo jo 
    if($res==true){
        //zhanri eshte fshire , shfaq mesazhin npm session
        
        
        $_SESSION['delete']= "<div class='success'>Zhanri u fshi me sukses</div>";
       
        header('location:'.SITEURL.'admin/manage-genre.php');
    }
    else{
         
        
        $_SESSION['delete']= "<div class='error' > Zhanri nuk u fshi. Provoni përsëri.</div";
        header('location:'.SITEURL.'admin/manage-genre.php');
    }
  
?>