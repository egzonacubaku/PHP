<?php include('../config/constants.php');?>
<html>
    <head>
        <title>Login-Movie System</title>
        <link rel="stylesheet" href="..\\css/admin.css">
    </head>
    <body>
    <div class="body-login">
        
<br><br>

    <?php 
    //kete kopjoje dhe tek index.php
        if(isset($_SESSION['login']))
        {
            echo $_SESSION['login'];
            unset($_SESSION['login']);
        }
        if(isset($_SESSION['no-login-message']))
        {
            echo $_SESSION['no-login-message'];
            unset($_SESSION['no-login-message']);
        }
    ?>
<br><br>
        <!-- Login form fillon -->
        
        <div class="flex-container">
            <div class="content-container">
                <div class="form-container">
                    <form action="" method="POST">
                         <h1 class="h1-login">
                             Kyçu
                        </h1>
                        <br>
                        <br>
                        <span class="subtitle">USERNAME:</span>
                        <br><br>
                        <input style="padding-left:20px;" class="input-login" type="text" name="username" placeholder="Vendos username">
                        <br>
                        <span class="subtitle">PASSWORD:</span>
                        <br><br>
                        <input style="padding-left:20px;" class="input-login" type="password" name="password" placeholder="Vendos password">
                        <br> <br>
                        <input type="submit" name="submit" value="Kyçu" class="input-login submit-btn">
                        <br><br>

                    </form>
                </div>
            </div>
        </div>
        <!-- Login form mbaron -->
    
    </div>

    </body>
</html> 

<?php

//kontroll nese butoni submit eshte klikuar apo jo
if(isset($_POST['submit']))
{
    
    //1.merr te dhenat nga forma login  
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    //2.sql query per te kontrolluar nese useri/admin egziston apo jo
    $sql = " SELECT * FROM admin WHERE username='$username' AND password='$password'";
            
     //3.execute the query
     $res = mysqli_query($conn , $sql);//qe kjo te behet duhet te perfshijme konstantet ,
                                    //ne faqet e tjera i kemi perfshire nga menu-ja por kti nuk kemi menu,prandaj e shtojme ne fillim
        
     //4.numerim rreshtash per te te pare nese egziston
     $count = mysqli_num_rows($res);
 
     if ($count==1)
     {
        // useri egziston eshte loguar
        $_SESSION['login'] = "<div class='success'> Login Successful</div>";
        $_SESSION['user'] = $username ;// per te pare nese useri eshte loguar apo jo , perdoret tek logout
        
        //kalo tek home page/dashboard
        header('location:'.SITEURL.'admin/');
        

        //keto dy session duhet te shfaqen dhe do i bejme ne fillim te faqes
     }
     else
     {
        //user not available
        $_SESSION['login'] = "<div class='error text-center'> Username or Password did not match</div>";
        //kthehu tek faqja login
        header('location:'.SITEURL.'admin/login.php');
     }
}
?>