<?php include('partials/menu.php');?>

<div class="main-content">
    <div class="wrapper">
        <h1>Ndrysho Zhanrin</h1>
        <br> <br>
        <?php 
            //1. merr id e zhanrit te selektuar 
            $gnr_id=$_GET['gnr_id'];

            //2. sql per te marre te dhenat nga db per kete zhaner 
            $sql="SELECT * FROM genre WHERE gnr_id=$gnr_id";

            //Execute the query
            $res = mysqli_query($conn, $sql);
            //kontroll nese query eshte egzekutuar apo jo 
            if($res==true)
            {
                
                $count = mysqli_num_rows($res);
                //nese ka te dhena , kontroll 
                if($count==1)
                {
                 //merr te dhenat 
                 
                 $row=mysqli_fetch_assoc($res);
                 $title = $row['title'];
                 $description = $row['description'];
                 
                }
                else 
                {
                    
                    header('location:'.SITEURL.'admin/manage-genre.php');
                }
            }

        ?>
        <form action="" method="POST">
            <table class="tbl-30">
                <tr>
                    <td>Titulli: </td>
                    <td>
                       <input type="text" name="title" value="<?php echo $title;?>">

                    </td>
                </tr>
                <tr>
                            <td>Përshkrimi:</td>
                            <td>
                                <textarea name="description" cols="30" rows="5" ><?php echo $description; ?></textarea>
                            </td>
                        </tr>

                <tr>
                    <td colspan="2"> 
                        <input type="hidden" name="gnr_id" value="<?php echo $gnr_id; ?>">
                        <input type="submit" name="submit" value="Ndrysho" class="btn-secondary">
                    </td>
                    
                </tr>

                

            </table>
        </form>
    </div>
</div>

<?php 
    
    if(isset($_POST['submit']))
    {
        
        //merr te dhenat nga forma 
        $gnr_id = $_POST['gnr_id'];
        $title = $_POST['title'];
        $description = $_POST['description'];

        //sql per te bere update 
        $sql = "UPDATE genre SET 
        title = '$title',
        description = '$description' 
        WHERE gnr_id ='$gnr_id'
        ";

        //execute the query
        $res = mysqli_query($conn, $sql);

        //kontroll nese query esht eegzekutuar 
        if($res==true)
        {
            //zhanri esht eupdate, shfaq mesazh 
            $_SESSION['update']= "<div class='success'>Zhanri u ndryshua me sukses.</div>";
            //Redirect to manage admin page
            header('location:'.SITEURL.'admin/manage-genre.php');
        }
        else
        {
            //failed to update admin
            $_SESSION['update']= "<div class='error'>Zhanri nuk u ndryshua.</div>";
            //Redirect to manage admin page
            header('location:'.SITEURL.'admin/manage-genre.php');
        }
    }
?>
<?php include('partials/footer.php'); ?>