<?php

    //perfshihet file qe kemi lidhjen me db 
    include('../config/constants.php');

    //1. merr id e adminit qe duam te fshijme 
      $id=$_GET['id'];
    //2. krijojme kodin sql per te fshire adminin
        $sql = "DELETE FROM admin WHERE id=$id";

    
    $res = mysqli_query($conn,$sql);
    //kontroll nese query eshte egzekutuar apo jo
    if($res==true){
        //Admini u fshi , shfaq mesazhin  
        $_SESSION['delete']= "<div class='success'>Admini u fshi me sukses</div>";
        //kthehu te faqja manage-admin 
        header('location:'.SITEURL.'admin/manage-admin.php');
    }
    else{
       
        $_SESSION['delete']= "<div class='error' > Admini nuk u fshi. Provo përsëri..</div";
        header('location:'.SITEURL.'admin/manage-admin.php');
    }
   

?>