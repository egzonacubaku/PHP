<?php include('partials/menu.php');?>
<?php  ob_start(); ?>
    <?php  
     
        //check whether id is set or not
        if(isset($_GET['movie_id']))
        {
            //merr te dhenat 
            $movie_id = $_GET['movie_id'];
            //merr te dhenat nga db per filmin e selektuar 
            $sql2 = "SELECT * FROM movie WHERE movie_id = $movie_id";
            //execute the query
            $res2= mysqli_query($conn,$sql2);

            
            $row2 = mysqli_fetch_assoc($res2);

            //merr te dhenat individuale per filmin 
            $title = $row2['title'];
            $director= $row2['director'];
            $production_place= $row2['production_place'];
            $type=$row2['type'];
            $current_image = $row2['image_name'];
            $current_genre = $row2['gnr_id'];
            $summary = $row2['summary'];
           
        }
        else
        {
            //redirect to manage-food
            header('location:'.SITEURL.'admin/manage-movie.php');
        }
    ?>


    <div class="main-content">
        <div class="wrapper">
                <h1>Ndrysho Filmin</h1>

                <br><br>
                <form action="" method="POST" enctype="multipart/form-data">

                    <table class="tbl-30">
                        <tr>
                            <td>Titulli:</td>
                            <td>
                                <input type="text" name="title" value="<?php echo $title ; ?>" >
                            </td>
                        </tr>
                        <tr>

                        <td>Regjisori: </td>
                        <td>
                            <input type="text" name="director"  value="<?php echo $director; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Vendi i prodhimit: </td>
                        <td>
                            <input type="text" name="production_place" value="<?php echo $production_place; ?>">
                        </td>
                    </tr>

                    <tr>
                        <td>Përmbledhja: </td>
                        <td>
                            <textarea name="summary"  cols="25" rows="5" ><?php echo $summary; ?> </textarea>
                        </td>
                    </tr>
                   

                        <tr>
                            <td>Fotoja aktuale:</td>
                            <td>
                                <?php
                                    if($current_image=="")
                                    {
                                        //image not available
                                        echo "<div class='error'>Nuk ka foto.</div>";
                                    }
                                    else
                                    {
                                        //image available
                                        ?>
                                        <img src="<?php echo SITEURL;?>movies/images/<?php echo $current_image;?>" width="150px">
                                        <?php
                                    }
                                    ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Zgjidh foton e re: </td>
                            <td>
                                <input type="file" name="image_name">
                            </td>
                        </tr>

                        <tr>
                            <td>Zhanri:</td>
                            <td>
                                <select name="genre" >

                                    <?php
                                        //query per te marre zhanret nga db 
                                        $sql = "SELECT * FROM genre ";
                                        //execute the query
                                        $res = mysqli_query($conn , $sql);
                                        //numero rreshtat per te pare nese ka zhanre ne db 
                                        $count = mysqli_num_rows($res);
                                        //kontroll nese ka zhanre ne db
                                        if($count>0)
                                        {
                                            //ka zhanre ne db 
                                            while($row=mysqli_fetch_assoc($res))
                                            {
                                                $title = $row['title'];
                                                $gnr_id = $row['gnr_id'];

                                                //marrim te dhenat dhe shfaqim titullin e zhanrin si dropdown 
                                                ?>
                                                <option <?php if($current_genre==$gnr_id){echo "selected";}?> value="<?php echo $gnr_id;?>"><?php echo $title;?></option>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            
                                            echo "<option value='0' >Nuk ka zhaner.</option>";
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                        <td>Tipi:</td>
                        <td>
                            <select name="type">
                            <option <?php if($type=="Film"){echo "selected";}?> value="Film">Film</option>
                            <option <?php if($type=="Serial"){echo "selected";}?>value="Serial">Serial</option>
                            <option <?php if($type=="Documentary"){echo "selected";}?> value="Documentary">Documentary</option>
                            
                            </select>
                        </td>
                    </tr>

                        <tr>
                            <td>
                                 <input type="hidden" name="movie_id" value="<?php echo $movie_id;?>">
                                 <input type="hidden" name="current_image" value="<?php echo $current_image;?>">

                                <input type="submit" name="submit" value="Ndrysho" class="btn-secondary">
                            </td>
                        </tr>
                    </table>
                </form>
                <?php
               
                    //kontrollo nese butoni eshte klikuar apo jo
                    if(isset($_POST['submit']))
                    {
                       
                       //1.merr te dhenat nga forma
                       $movie_id = $_POST['movie_id'];
                       $title = $_POST['title'];
                       $current_image = $_POST['current_image'];
                       $genre = $_POST['genre'];
                       $title = $_POST['title'];
                       $director = $_POST['director'];
                       $production_place = $_POST['production_place'];
                       $type = $_POST['type'];
                       $avg_rate =$_POST['avg_rate'];
                       $summary = $_POST['summary'];

                      
                       //2.upload the image if selected
                       
                       if(isset($_FILES['image_name']['name']))
                       {
                           
                           $image_name = $_FILES['image_name']['name']; //new image name
                           
                           if($image_name !="")
                           {
                               //image is available
                               //A.Uploading new image
                               //rename the image
                               $ext = end(explode('.', $image_name)); //get the extension of the image
                               $image_name = "Movie-Foto-".rand(0000, 9999).'.'.$ext;//rename the image
                               //get the source path and destination path
                               $src_path = $_FILES['image_name']['tmp_name'];
                               $dest_path = "../movies/images/".$image_name;
                               //upload the image
                               $upload = move_uploaded_file($src_path,$dest_path);
                               //check whether the image is uploaded or not
                               if($upload==false)
                               {
                                   //failed to upload
                                   $_SESSION['upload'] = "<div class='error'>Fotoja e re nuk u ndryshua.</div>";
                                 
                                   header('location:'.SITEURL.'admin/manage-movie.php');
                                   //stop the process
                                   die();
                               }
                               //3.remove the image if new image is uploaded and current image exist
                               //B.remove current image if available
                               if($current_image!="")
                               {
                                   //current image is available
                                   //remove the image
                                   $remove_path = "../movies/images/".$current_image;

                                   $remove = unlink($remove_path);
                                   //check whether the image is removed or not
                                   if($remove==false)
                                   {
                                       //failed to remove current image
                                       $_SESSION['remove-failed'] = "<div class='error' >Fotoja aktuale nuk u ndryshua . </div>";
                                      
                                       header('location:'.SITEURL.'admin/manage-movie.php');
                                       //stop the process
                                       die();
                                   }
                               }
                           }
                           else
                           {
                               $image_name = $current_image;
                           }
                       }
                       else
                       {
                           $image_name = $current_image;
                       }
                       //4.mupdate movie ne db
                       $sql3 = "UPDATE movie SET 
                         title = '$title',
                        director = '$director',
                        production_place ='$production_place',
                        gnr_id = '$genre',
                        type ='$type',
                        avg_rate ='$avg_rate',
                        summary='$summary',
                        image_name = '$image_name'
                        WHERE movie_id=$movie_id

                       ";

                       //execute  sql query 
                       $res3 = mysqli_query($conn, $sql3);
                       //kontroll nese query eshte egzekutuar apo jo  
                       if($res3==true)
                       {
                           //movie updated , shfaq mesazhin 
                           $_SESSION['update'] = "<div class='success' > Të dhënat e filmit u ndryshuan me sukses.</div>";
                           header('location:'.SITEURL.'admin/manage-movie.php');
                       }
                       else
                       {
                           //failed to update movie
                           $_SESSION['update'] = "<div class='error' > Filmi nuk u ndryshua.</div>";
                           header('location:'.SITEURL.'admin/manage-movie.php');
                       }
                    }
                    
                ?>

        </div>
    </div>
    <?php ob_end_flush(); //sepse nxjerr error heading kane nisur ....?>
<?php include('partials/footer.php');?>