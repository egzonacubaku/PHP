<?php include('partials/menu.php');?>
<?php  ob_start(); ?>
    <div class="main-content">
        <div class="wrapper">
            <h1>Shto film</h1>
            <br><br>

            <?php 
                if(isset($_SESSION['upload']))
                {
                    echo $_SESSION['upload'];
                    unset($_SESSION['upload']);
                }
            ?>

            <form action="" method="POST" enctype="multipart/form-data">

                <table class="tbl-30">
                    <tr>
                        <td>Titulli: </td>
                        <td>
                            <input type="text" name="title" placeholder="Titulli i filmit">
                        </td>
                    </tr>

                    <tr>
                        <td>Regjisori: </td>
                        <td>
                            <input type="text" name="director" placeholder="...">
                        </td>
                    </tr>

                    <tr>
                        <td>Vendi i prodhimit: </td>
                        <td>
                            <input type="text" name="production_place" placeholder="vendi">
                        </td>
                    </tr>


                    <tr>
                        <td>Përmbledhja: </td>
                        <td>
                            <textarea name="summary" placeholder="...." cols="25" rows="5" > </textarea>
                        </td>
                    </tr>

                   

                    <tr>
                        <td>Tipi:</td>
                        <td>
                            <select name="type">
                            <option value="Film">Film</option>
                            <option value="Serial">Serial</option>
                            <option value="Documentary">Documentary</option>
                            
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td>Zhanri:</td>
                        <td>
                            <select name="genre">
                                <?php 
                                    
                                    //1. merr te dhena nga db per te shfaqur alternativat e zhanrin ne nje drop down 
                                    $sql="SELECT * FROM genre ";
                                    
                                    //execute query
                                    $res = mysqli_query($conn, $sql);

                                    //numerim i rreshtave per te pare nese ka te dhena ne db 
                                    $count = mysqli_num_rows($res);

                                    
                                    if($count>0)
                                    {
                                        //ka zhanre ne db  
                                        while ($row=mysqli_fetch_assoc($res))
                                        {
                                            //merr te thenat e zhanrit ne db
                                            $gnr_id = $row['gnr_id'];
                                            $title=$row['title'];
                                            ?>

                                            <option value="<?php echo $gnr_id;?>"><?php echo $title;?></option>


                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        //nuk ka te dhena mbi zhanrin ne db
                                        ?>
                                        <option value="0">No Genre Found</option>
                                        <?php
                                    }

                                   
                                ?>

                                
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Zgjidh foton:</td>
                        <td>
                            <input type="file" name="image_name" >
                        </td>
                    </tr>


                    <tr>
                        <td colspan="2">
                            <input type="submit" name="submit" value="Shto " class="btn-secondary">
                        </td>
                    </tr>


                </table>
            </form>

            <?php 
                   
                    if(isset($_POST['submit']))
                    {
                        //shto movie ne db 
                       // echo "clicked";

                       //1. merr te dhant nga forma 

                       $title = $_POST['title'];
                       $director = $_POST['director'];
                       $production_place = $_POST['production_place'];
                       $genre = $_POST['genre'];
                       $type = $_POST['type'];
                       $avg_rate =$_POST['avg_rate'];
                       $summary = $_POST['summary']; 
                       
                       //2. upload nese eshte zgjedhur foto
                     
                       if(isset($_FILES['image_name']['name']))
                       {
                            //merr te dhenat e fotos 
                            $image_name= $_FILES['image_name']['name'];

                            
                            if($image_name !="")
                            {
                                
                                //A.rename the image
                                //get the extention of selected image (jpg,gif etc)
                                $ext = end(explode('.', $image_name));
                                //krijo nje emer te ri per foton 
                                $image_name = "Movie-Name-".rand(0000,9999).".".$ext; 
                

                                //B. upload the image
                             

                                //source path eshte vendodhja aktuale e fotos 
                                $src=$_FILES['image_name']['tmp_name'];

                                //destination path eshte vendodhja ku do ruhet  fotoja 
                                $dst = "../movies/images/".$image_name;

                                // uppload image 

                                $upload = move_uploaded_file($src, $dst);

                                //kontroll nese fotoja eshte uploaduar apo jo
                                if($upload==false)
                                {
                                    //fotoja nuk eshte bere upload, shfaq mesazhin 
                                   
                                    $_SESSION['upload'] = "<div class='error'>Failed to upload the image</div>";
                                    header('location:'.SITEURL.'admin/add-movie.php');
                                    //stop the process
                                    die();
                                }
                            }
                       }
                       else
                       {
                            $image_name = ""; //vlera default nese nuk ka foto
                       }

                    

                       //3. Hedhja e te dhenave ne db 
                       if(!preg_match('~[0-9]+~', $title) && preg_match( '/[a-zA-Z]/ ', $title) && !preg_match('~/[^a-zA-Z\d]/+~', $title) && !empty($title)) 
                       {

                       $sql_u = "SELECT * FROM movie WHERE title='$title'";
                       $res_u = mysqli_query($conn, $sql_u);
                       if (mysqli_num_rows($res_u) > 0) 
                       {
                           $_SESSION['add'] = "<div class='error'>Ky film egziston.</div>";
                           //kthim tek manage genre 
                           header('location:'.SITEURL. 'admin/add-movie.php');
                       }
                       else {
                      
                       $sql2 = "INSERT INTO movie  SET
                        title = '$title',
                        director = '$director',
                        production_place ='$production_place',
                        gnr_id = '$genre',
                        type ='$type',
                        avg_rate ='$avg_rate',
                        summary='$summary',
                        image_name = '$image_name'
                        
                       
                       ";

                       //execute the query
                       $res2 = mysqli_query($conn , $sql2);
                       //kontroll nese te dhenat jane vendosur ne db , shfaq mesazh
                   
                       if($res2==true)
                       {
                           //te dhenat jane bere insert
                           $_SESSION['add'] = "<div class='success' >Filmi u shtua me sukses. </div>";
                           header('location:'.SITEURL.'admin/manage-movie.php');
                       }
                       else
                       {
                           
                           $_SESSION['add'] = "<div class='error' >Filmi nuk u shtua. </div>";
                           header('location:'.SITEURL.'admin/manage-movie.php');
                       }

                    }
                }
                else
                {
                    $_SESSION['add'] = "<div class='error'>Filmi nuk u shtua ! Titulli duhet te jete tekst.</div>";
                        
                    header('location:'.SITEURL. 'admin/add-movie.php');
                }
                    }

            ?>
    
        </div>
    </div>
    <?php ob_end_flush();?>
<?php include('partials/footer.php');?>