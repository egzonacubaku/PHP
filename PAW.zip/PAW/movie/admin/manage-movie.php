<?php include('partials/menu.php') ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Filmat </h1> 
    
    <br/><br/>
                <a href="<?php echo SITEURL;?>admin/add-movie.php" class="btn-primary">Shto një film </a>
                <br/> <br/> <br/>

                <?php 
                     if(isset($_SESSION['add']))
                     {
                         echo $_SESSION['add'];
                         unset($_SESSION['add']);
                     }

                     if(isset($_SESSION['delete']))
                     {
                         echo $_SESSION['delete'];
                         unset($_SESSION['delete']);
                     }

                     if(isset($_SESSION['upload']))
                     {
                         echo $_SESSION['upload'];
                         unset($_SESSION['upload']);
                     }

                     if(isset($_SESSION['unauthorize']))
                     {
                         echo $_SESSION['unauthorize'];
                         unset($_SESSION['unauthorize']);
                     }

                     if(isset($_SESSION['remove-failed']))
                     {
                         echo $_SESSION['remove-failed'];
                         unset($_SESSION['remove-failed']);
                     }

                     if(isset($_SESSION['update']))
                     {
                         echo $_SESSION['update'];
                         unset($_SESSION['update']);
                     }


                ?>


               <table class="tbl-full">
                   <tr>
                       <th style="text-align:center;">Nr.</th>
                       <th style="text-align:center;">Titulli</th>
                       <th style="text-align:center;">Regjisori</th>
                       
                       <th style="text-align:center;">Foto </th>
                        
                       <th style="text-align:center;">Veprimet</th>
                   </tr>
                   <?php 
                    //sql per te marre te dhenat e fimlave nga db  
                    $sql = "SELECT * FROM movie";

                    //execute the query
                    $res = mysqli_query($conn , $sql);

                    //numerojme rreshtat per te par enese ka filma ne db apo jo 
                    $count = mysqli_num_rows($res);

                    //krijojme nje var sn per te shfaqur te dhenat 
                    $sn=1;

                    if($count>0)
                    {
                        
                        //marrim te dhenat e filmave nga db dhe i shfaq
                        while ($row=mysqli_fetch_assoc($res))
                        {
                            //merr te dhenat nga kolonat ne db tek variablat
                            $movie_id=$row['movie_id'];
                            $title = $row['title'];
                            $director = $row['director'];
                            $type = $row['type'];
                            $image_name = $row['image_name'];
                            
                            $summary = $row['summary'];
                            $production_place = $row['production_place'];
                           
                            $avg_rate = $row['avg_rate'];
                            ?>
                                    <tr>
                                    <td style="text-align:center;"><?php echo $sn++;?></td>
                                    <td style="text-align:center;"><?php echo $title;?></td>
                                    <td style="text-align:center;"><?php echo $director;?></td>                    
                                    <td style="text-align:center;">
                                        <?php 
                                            //kontroll nese ka foto apo jo 
                                            if($image_name=="")
                                            {
                                                //nuk ka foto , shfaqet mesazhi
                                                echo "<div class='error' >Image not Added.</div";
                                            }
                                            else
                                            {
                                                //ka foto , shfaqet fotoja 
                                                ?>
                                                <img src="<?php echo SITEURL;?>movies/images/<?php echo $image_name;?>"width="150px">
                                                <?php

                                            }
                                        ?>
                                    </td>
                                   
                                    
                                    <td>
                                            <a href="<?php echo SITEURL; ?>admin/update-movie.php?movie_id=<?php echo $movie_id;?>" class="btn-extra">Ndrysho të dhënat  </a>
                                            <a href="<?php echo SITEURL; ?>admin/delete-movie.php?movie_id=<?php echo $movie_id;?>&image_name=<?php echo $image_name;?>" class="btn-danger">Fshij filmin</a>
                                    </td>
                                </tr>
                            <?php
                        }

                    }
                    else
                    {
                        //filmi nuk eshte shtuar 
                        echo "<tr > <td colspan='7' class='error'>Movie not Added Yet.</td></tr>";
                    }
                   ?>
                  
                 
               </table>
               </div>
</div>

<?php include('partials/footer.php') ?>