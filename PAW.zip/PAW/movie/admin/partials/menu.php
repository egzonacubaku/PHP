<?php 
    include('../config/constants.php');
    include('login-check.php');


?>
<html>
    <head>
        <title>Movie-Home Page </title>
        <link rel="stylesheet" href="..\\css/admin.css">
    </head>
    <body>
        <!-- Fillon munu-ja-->
        <div class="menu text-center">
            <div class="wrapper"> 
            <ul>
                <li><a href="index.php">Faqja Kryesore </a></li>
                <li><a href="manage-admin.php">Admin  </a></li>
                <li><a href="manage-genre.php">Zhanri</a></li>
                <li><a href="manage-movie.php">Filmat </a></li>
                <li><a href="manage-users.php">Përdoruesit </a></li>
                <li><a href="logout.php">Dil </a></li>
            </ul>
            </div> 
               
         </div>
      