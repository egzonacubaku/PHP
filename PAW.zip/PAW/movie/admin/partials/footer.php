
<div class="footer">
            <div class="wrapper"> 
                <p class="text-center">© 2021 PAW - MSHSIE. Të gjitha të drejtat të rezervuara.<a href="a"> </a> </p>
            </div>  
         </div>
         


    </body>
</html>