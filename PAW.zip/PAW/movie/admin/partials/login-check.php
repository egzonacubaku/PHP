<?php 
    //authorization-access control
    //kontroll nese useri eshte loguar apo jo
    if(!isset($_SESSION['user'])) 
    {
        //useri nuk eshte loguar
        //kthehu tek faqja e login-it me nje mesazh
        $_SESSION['no-login-message'] = "<div class='error text-center'>Ju lutem kyçuni për të aksesuar panelin e administratorit..</div>";
        //redirect to login page
        header('location:'.SITEURL.'admin/login.php');
        
    }
?>