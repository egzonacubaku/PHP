<?php include('partials/menu.php') ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Zhanret</h1> 
    
    <br/><br/>
    <?php 
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add'];
                unset($_SESSION['add']);
            }

            if(isset($_SESSION['remove']))
            {
                echo $_SESSION['remove'];
                unset($_SESSION['remove']);
            }

            if(isset($_SESSION['delete']))
            {
                echo $_SESSION['delete'];
                unset($_SESSION['delete']);
            }

            if(isset($_SESSION['no-category-found']))
            {
                echo $_SESSION['no-category-found'];
                unset($_SESSION['no-category-found']);
            }
            
            if(isset($_SESSION['update']))
            {
                echo $_SESSION['update'];
                unset($_SESSION['update']);
            }

            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }

            if(isset($_SESSION['failed-remove']))
            {
                echo $_SESSION['failed-remove'];
                unset($_SESSION['failed-remove']);
            }


  
    ?>
        <br><br>
                <a href="<?php echo SITEURL;?>admin/add-genre.php" class="btn-primary">Shto zhanër të ri  </a>
                <br/> <br/> <br/>
               <table class="tbl-full">
                   <tr>
                       <th style="text-align:center;">Nr.</th>
                       <th style="text-align:center;">Titulli</th>
                       <th style="text-align:center;">Përshkrimi</th>
                       <th style="text-align:center;">Veprimet</th>
                      
                   </tr>

                   <?php 
                        //query per te marre te dhenat e tabeles genre (zhanri ) ne db 
                        $sql = "SELECT * FROM genre";
                        //execute query
                        $res = mysqli_query($conn , $sql);

                        //count rows
                        $count = mysqli_num_rows($res);

                        //krijojme nje variabel sn qe do e perdorim per te shfaqur te dhenat ne tabele ne faqe "renditje inkrementale"
                        $sn=1;

                        //kontroll nese ka te dhena  
                        if($count>0)
                        {
                            
                            //merr te dhenat nga db dhe shfaqi
                            while($row=mysqli_fetch_assoc($res))
                            {
                                $gnr_id = $row['gnr_id'];
                                $title = $row['title'];
                                $description = $row['description'];
                
                                ?>
                                     <tr>
                                        <td style="text-align:center;"><?php echo $sn++;?></td>
                                        <td style="text-align:center;"><?php echo $title;?></td>
                                        <td style="text-align:center;"><?php echo $description;?></td>

                                        <td style="text-align:center;">
                                                <a href="<?php echo SITEURL;?>admin/update-genre.php?gnr_id=<?php echo $gnr_id;?>" class="btn-extra">Ndrysho  </a>
                                                <a href="<?php echo SITEURL;?>admin/delete-genre.php?gnr_id=<?php echo $gnr_id;?>" class="btn-danger">Fshij  </a>
                                        </td>
                                     </tr>

                                
                                <?php
                            }

                        }
                        else
                        {
                            //nuk ka te dhena ne db , shfaq mesazhin 
                            ?>
                            <tr>
                                <td colspan="5"><div class="error">Nuk ka zhanër. </div></td>
                            </tr>

                            <?php
                        }
                   
                   
                   ?>
                  
                   
                  
               </table>
          </br></br>     
</div>

<?php include('partials/footer.php') ?>