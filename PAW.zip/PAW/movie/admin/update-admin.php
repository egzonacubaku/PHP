<?php include('partials/menu.php') ;?>
<div class="main-content">
    <div class="wrapper">
        <h1>Ndrysho Adminin</h1>
        <br> <br>
        <?php 
            //1. merr id e adminit te klikuar per tu update-uar  
            $id=$_GET['id'];

            //2. sql per te marre te dhenat nga db per adminin e zgjedhur 
            $sql="SELECT * FROM admin WHERE id=$id";

           
            $res = mysqli_query($conn, $sql);
            //kontroll nese query eshte egzekutuar apo jo 
            if($res==true)
            {
                //kontroll nese ka te dhena ne db 
                $count = mysqli_num_rows($res);
                
                if($count==1)
                {
                 //get the details
                // echo "Admin Available";
                 $row=mysqli_fetch_assoc($res);

                 $full_name = $row['full_name'];
                 $username =$row['username'];
                }
                else 
                {
                    //nese nuk egziston, kthim tek faqja manage-admin
                    header('location:'.SITEURL.'admin/manage-admin.php');
                }
            }

        ?>
        <form action="" method="POST">
            <table class="tbl-30">
                <tr>
                    <td>Emri: </td>
                    <td>
                       <input type="text" name="full_name" value="<?php echo $full_name;?>">

                    </td>
                </tr>
                <tr>
                    <td>Username: </td>
                    <td>
                       <input type="text" name="username" value="<?php echo $username; ?>">

                    </td>
                </tr>

                <tr>
                    <td colspan="2"> 
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Ndrysho" class="btn-secondary">
                    </td>
                    
                </tr>

                

            </table>
        </form>
    </div>
</div>

<?php 
   
    if(isset($_POST['submit']))
    {
        
        //merr te dhenat nga forma
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $username = $_POST['username'];

        //sql per te update-uar adminin 
        $sql = "UPDATE admin SET 
        full_name = '$full_name',
        username = '$username' 
        WHERE id ='$id'
        ";

        //execute the query
        $res = mysqli_query($conn, $sql);

        //kontroll nese query eshte egzekutuar 
        if($res==true)
        {
            //admini eshte update-uar , shfaq mesazhin 
            $_SESSION['update']= "<div class='success'>Admini u ndryshua me sukses.</div>";
            //kthim tek faqja manage-admin 
            header('location:'.SITEURL.'admin/manage-admin.php');
        }
        else
        {
            //nuk eshte update-uar admini 
            $_SESSION['update']= "<div class='error'>Admini nuk u ndryshua.</div>";
            
            header('location:'.SITEURL.'admin/manage-admin.php');
        }
    }
?>
<?php include('partials/footer.php'); ?>