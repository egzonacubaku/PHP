<?php 
       
      include('../config/constants.php'); 

    if(isset($_GET['movie_id']) && isset($_GET['image_name']))
    {
        //Procesi per te fshire 
       

        //1.merr id dhe image_name
        $movie_id = $_GET['movie_id'];
        $image_name = $_GET['image_name'];


        //2.fshi foton nese ka 
        
        if($image_name !="")
        {
            
            //merr path-in e fotos 
            $path = "../movies/images/".$image_name;

            //hiq file-in e fotos nga folderi i fotove 
            $remove = unlink($path);
            
            //kontroll nese fotoja eshte fshire apo jo 
            if($remove==false)
            {
                //fotoja nuk eshte fshire, shfaq mesazh  
                $_SESSION['upload'] = "<div class='error' >Fotoja nuk u fshi !.</div>";
                //kthim tek faja manage-movie
                header('location:'.SITEURL.'admin/manage-movie.php');
                
                die();
            }
        }

        //3.fshi filmin nga db 
        $sql = "DELETE FROM movie WHERE movie_id=$movie_id";
        //execute the query
        $res=mysqli_query($conn, $sql);

        //kontroll nese query eshte egzekutuar 
        if($res==true)
        {
            //filmi eshte fshire, shfaqim mesazhin
            $_SESSION['delete'] = "<div class='success'>Filmi u fshi me sukses. </div>";
            header('location:'.SITEURL.'admin/manage-movie.php');

        }
        else
        {
            
            $_SESSION['delete'] = "<div class='error'>Filmi nuk u fshi. </div>";
            header('location:'.SITEURL.'admin/manage-movie.php');
        }

    }
    else
    {
        
       //Nese nuk ka kaluar id , image_name i filmit 
       $_SESSION['unauthorize'] = "<div class='error'>Unauthorized Access.</div>";
       header('location:'.SITEURL.'admin/manage-movie.php');
    }
?> 
    